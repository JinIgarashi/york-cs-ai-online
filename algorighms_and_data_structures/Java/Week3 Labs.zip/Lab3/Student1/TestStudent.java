
public class TestStudent {

	public static void main(String[] args) {
		PhDStudent s=new PhDStudent();
		s.displayDetails();

	}

}
