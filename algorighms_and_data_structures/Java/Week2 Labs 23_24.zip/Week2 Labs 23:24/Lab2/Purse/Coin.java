public class Coin
{  
   // instance variables to store the value and name
 
   private double value;
    
    // a constructor for constructing a coin 

   public Coin(double aValue)
   {  value = aValue;
   }

   // methods to access the value and name

   public double getValue()
   {  return value;
   }

}
