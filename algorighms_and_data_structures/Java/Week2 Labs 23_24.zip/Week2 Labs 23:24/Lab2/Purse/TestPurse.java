
public class TestPurse {

	public static void main(String[] args) {
		//Create a purse and some coins, then add the coins to the purse, 
		//and finally work out the total in the purse

	}

}
