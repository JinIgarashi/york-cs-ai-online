
/**
 * ProductTest
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ProductTest
{
	public void startProductTests()
	{
	  //First create a Product  Object - testing the constructor  
	  
	  
	  System.out.println("Starting Tests");
	  
	  //Now Test all the methods
	
	
	
	}//End of StartProductTests()
}
