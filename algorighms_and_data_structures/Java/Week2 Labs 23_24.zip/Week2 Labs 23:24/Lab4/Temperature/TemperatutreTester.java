
public class TemperatutreTester {

	public static void main(String[] args) {
		//Create temperature object and text the methods
		Temperature t=new Temperature();
		t.basicArrayAccess();
		t.interactiveArray();

	}

}
