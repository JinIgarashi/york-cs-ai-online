
public class MenuNotebookTester {

	public static void main(String[] args) {
		
		//Create Notebook objects and test the methods
				MenuNotebook n=new MenuNotebook();
				n.runMenu();
				
	}

}
