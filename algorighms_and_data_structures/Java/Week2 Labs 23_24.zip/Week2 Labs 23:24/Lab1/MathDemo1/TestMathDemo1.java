
public class TestMathDemo1 {

	public static void main(String[] args) {
		// Create MathDemo1 object and test the methods

	}

}
