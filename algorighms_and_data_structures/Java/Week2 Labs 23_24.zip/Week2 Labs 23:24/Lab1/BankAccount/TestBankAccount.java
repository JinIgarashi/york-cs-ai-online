
public class TestBankAccount {

	public static void main(String[] args) {
		// Create BanAccount object and test the methods

	}

}
