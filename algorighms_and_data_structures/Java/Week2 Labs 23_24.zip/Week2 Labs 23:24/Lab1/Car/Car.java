class Car
{
    String registration;
    String make;
    double price;
    
    //Methods to set car details below here
    
    
    
    //displayCarDetails()
    
    
    
    //Try out these 'getter' methods after you have set info.
    public String getRegistration()
    {
       return registration;
    }
    
    public String getMake()
    {
        return make;
    }

    public double getPrice()
    {
        return price;
    }
}


