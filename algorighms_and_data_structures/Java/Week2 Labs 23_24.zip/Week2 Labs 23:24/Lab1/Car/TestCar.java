
public class TestCar {

	public static void main(String[] args) {
		//Create Car object and text car methods 

	}

}
