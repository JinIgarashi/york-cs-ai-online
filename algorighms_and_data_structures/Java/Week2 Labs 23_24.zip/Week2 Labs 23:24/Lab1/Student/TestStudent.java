
public class TestStudent {

	public static void main(String[] args) {
		// Create student objects and test the methods

	}

}
