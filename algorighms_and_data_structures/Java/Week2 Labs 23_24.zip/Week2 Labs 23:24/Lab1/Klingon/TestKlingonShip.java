
public class TestKlingonShip {

	public static void main(String[] args) {
		
		// Create LingonShip object, then test the methods

	}

}
