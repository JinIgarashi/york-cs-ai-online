
public class TestSpaceShip3 {

	public static void main(String[] args) {
		//Create Spaceship objects and run the methods

	}

}
