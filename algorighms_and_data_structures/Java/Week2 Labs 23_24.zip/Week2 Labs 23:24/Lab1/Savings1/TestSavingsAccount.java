
public class TestSavingsAccount {

	public static void main(String[] args) {
		// create SavingsAccount object and test the methods

	}

}
