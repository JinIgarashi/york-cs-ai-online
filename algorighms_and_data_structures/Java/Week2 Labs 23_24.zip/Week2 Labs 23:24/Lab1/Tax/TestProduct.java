
public class TestProduct {

	 public static void main(String args[]) {
		
		 //Create Product objects and call the methods in the Product class
		//Product p1=new Product();
        //p1.setCostPrice();
        //p1.displayPriceDetails();
        //Product p2=new Product();
       //p2.displayPriceDetails();

	}

}
