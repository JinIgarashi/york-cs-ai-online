
public class TestPerson {

	public static void main(String[] args) {
		// Create Person object and test the methods

	}

}
