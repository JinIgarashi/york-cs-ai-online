
public class FlowerTest {

	public static void main(String[] args) {
		// Create 4 different flowers using the different constructors

	}

}
