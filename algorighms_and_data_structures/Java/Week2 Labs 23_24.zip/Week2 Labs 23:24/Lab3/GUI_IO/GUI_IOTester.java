
public class GUI_IOTester {

	public static void main(String[] args) {
		// Create GUI_IO and test all the methods

	}

}
