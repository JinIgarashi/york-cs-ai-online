
public class YorDateTester {
	public static void main(String args[])
	{
		//Create a reference to a YorDate object
		YorDate date1;
			
	    // This creates an object which sets the date to the current date
		 date1 = new YorDate();
		
		//Using the appropriate methods set, set date1 to your birthdate
	
		
		//Using appropriate date1 method(s) display your birthday
		
		
	}
}
